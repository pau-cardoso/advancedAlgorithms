// =========================================================
// File: main.cpp
// Author: Paulina Cardoso - A01701490
// Date: 08/11/2021
// =========================================================

#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <queue>
#include <climits>
#include <algorithm>

using namespace std;


/**
 * @brief Devuelve el nodo padre del nodo dado
 * 
 * @param i indice del nodo hijo
 * @param dads vector con los nodos padres de cada hijo
 * @return nodo padre del nodo dado
 */
int parents(int i, vector<int> &dads){
  while (dads[i] != i)
      i = dads[i];
  return i;
}
 
/**
 * @brief Genera un enlace entre 2 nodos al ser padre-hijo
 * 
 * @param i nodo hijo
 * @param j nodo padre
 * @param dads vector con los nodos padres de cada hijo
 */
void linkNodes(int i, int j, vector<int> &dads){  
  int a = parents(i, dads);
  int b = parents(j, dads);
  dads[a] = b;
}
 
/**
 * @brief Encuentra el arbol minimo de expansion con el algoritmo de Kruskal
 * 
 * @param graph grafo a recorrer
 * @param n numero de colonias en el grafo
 */
void mst(vector<vector<int>> graph, int n){
	int minCost = 0; 
	vector<int> dads(n);

	for (int i = 0; i < n; i++){
		dads[i] = i;
	}
	
	int edges = 0;
	while (edges < n - 1) {
		int min = INT32_MAX;
		int a = -1;
		int b = -1;

		for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			
			// Revisa que los padres de i sean distintos a los de j y que el costo sea menor al minimo
			if (parents(i, dads) != parents(j, dads) && graph[i][j] < min) {
			min = graph[i][j];
			a = i;
			b = j;
			}
		}
		}
		
		linkNodes(a, b, dads);
		edges++;
		minCost += min;

		cout << "(" << a << ", " << b << ")"<< endl;
	}
}


/**
 * @brief Algoritmo del agente viajero para pasar por cada nodo una vez y regresar al inicio
 * 
 * @param graph grafo a recorrer
 * @param n numero de colonias del grafo
 */
void travllingSalesmanProblem(vector<vector<int>> graph, int n){
	int s = 0;
	vector<int> aux, path, edges;
	
	for (int i = 0; i < n; i++){
		if (i != s){
			edges.push_back(i);
		}
	}
	
	int minCost = INT32_MAX;
	
	do {
		int currCost = 0;
		int k = s;
	
		for (int i = 0; i < edges.size(); i++) {
		currCost += graph[k][edges[i]];
		k = edges[i];
		aux.push_back(k);
		}
	
		aux.push_back(s);
		currCost += graph[k][s];

		if(minCost < currCost){
		path = aux;
		aux.clear(); 
		} 
	
		minCost = min(minCost, currCost);
	
	} while (next_permutation(edges.begin(), edges.end()));

	if(minCost < 0){
		cout << "There is no possible route." << endl;
	} else {	
		cout << "Minimum cost: " << minCost << endl;
		cout << "Path: ";

		for(int i = edges.size(); i >= 0; i--){
			cout << path[i] << " ";
		}

		cout << endl;
	}
}


/**
 * @brief Checa si aun hay rutas disponibles entre start y end
 * 
 * @param capacityMbps grafo con la capacidad en mbps de transferencias entre colonias
 * @param start colonia inicio
 * @param end colonia destino
 * @param parent arreglo para conectar caminos de colonias
 * @param n numero de colonias
 * @return verdadero si hay rutas entre la colonia inicio y destino que recorrer, falso si no
 */
bool bfs(vector<vector<int>> capacityMbps, int start, int end, int parent[],int n){
	
  	// Nodos visitados
	bool visited[n];
	memset(visited, 0, n);

	// Queue para nodos por visitar
	queue<int> q;
	q.push(start);
	visited[start] = true;
	parent[start] = -1;

	while (!q.empty()) {
		int j = q.front();
		q.pop();

    	// Regresamos true si encontramos un camino
		for (int i = 0; i < n; i++) {
			if (visited[i] == false && 0 < capacityMbps[j][i]) {
				if (i == end){
					parent[i] = j;
					return true; // Se encontro un camino
				}
				q.push(i);
				parent[i] = j;
				visited[i] = true;
			}
		}
	}
	return false; // No hay camino
}


/**
 * @brief Encuentra la capacidad maximo entre 2 colonias
 * 
 * @param graph grafo con las capacidades maximas entre colonias 
 * @param n numero de colonias
 * @param start colonia de inicio
 * @param end colonia final
 * @return transferencia maxima entre 2 colonias 
 */
void maximumFlow(vector<vector<int>> graph, int n, int start, int end){
	vector<vector<int>> capacityMbps(n,vector<int>(n)); 
	
	// Copia del grafo para la capacidad de mbps entre colonias
  	for (int i = 0; i < n; i++){
		for (int j = 0; j < n; j++){
			capacityMbps[i][j] = graph[i][j];
    	}
  	}
  
	int parent[n]; 
	int maxCapacity = 0; 
	
	// Mientras haya un camino
	while (bfs(capacityMbps, start, end, parent,n)) {
		
		// Se encuentra el flujo minimo que soporta
		int minFlow = INT32_MAX;
		for (int i = end; i != start; i = parent[i]) {
			int j = parent[i];
			minFlow = min(minFlow, capacityMbps[j][i]);
		}

		// Actualiza los flujos con el flujo minimo encontrado
		for (int i = end; i != start; i = parent[i]) {
			int j = parent[i];
			capacityMbps[j][i] -= minFlow;
		}
		maxCapacity += minFlow; // Se actualiza el flujo maximo
	}
	printf("Maximum flow from %i to %i is %i\n", start, end, maxCapacity);
}


void printProblem1(vector<vector<int>> graph, int n) {
	cout << "-------------------------------------" << endl;
	cout << "Problem 1" << endl;
	mst(graph, n);
}

void printProblem2(vector<vector<int>> graph, int n) {
	cout << "-------------------------------------" << endl;
	cout << "Problem 2" << endl;
	travllingSalesmanProblem(graph, n);
}

void printProblem3(vector<vector<int>> graph, int n, int start, int end) {
	cout << "-------------------------------------" << endl;
	cout << "Problem 3" << endl;
	maximumFlow(graph, n, start, end);
	cout << "-------------------------------------" << endl;
}

int main(int argc, char const *argv[]) {
	int n, start, end;
	cin >> n >> start >> end;

	vector<vector<int>> dirGraph, undGraph;
	
	for (int i = 0; i < n; i++) {
		vector<int> temp;
		for (int j = 0; j < n; j++) {
			int x;
			cin >> x;
			if(x == -1){
				x = INT32_MAX;
			}
			temp.push_back(x);
		}	
		undGraph.push_back(temp);
	}
	
	for (int i = 0; i < n; i++) {
		vector<int> temp;
		for (int j = 0; j < n; j++) {
			int x;
			cin >> x;
			temp.push_back(x);
		}	
		dirGraph.push_back(temp);
	}


	printProblem1(undGraph, n);
	printProblem2(undGraph, n);
	printProblem3(dirGraph, n, start, end);
	
	return 0;
}
