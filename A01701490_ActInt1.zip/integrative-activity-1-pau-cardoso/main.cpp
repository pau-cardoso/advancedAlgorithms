// =========================================================
// File: main.cpp
// Author: Paulina Cardoso Fuentes
// Date: 19/09/2021
// =========================================================

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

/**
 * @brief Funcion helper para el algoritmo KMP, donde se realiza un vector del patrón que se busca en el mensaje para no recorrer caracteres de nuevo
 * 
 * @param pattern - patrón que se busca en el mensaje
 * @param n - tamaño del patrón buscado
 * @param prefixArray - vector donde se guardará las ocurrencias en común para analizar posteriormente
 */
void prefixArray(string pattern, int n, vector<int>& prefixArray) {
    int length = 0;
    prefixArray.push_back(0);
    
    for (int i = 1; i < n; i++){
        if (pattern[i] == pattern[length]) {
            length++;
            prefixArray.push_back(length);    
        }else {
            if(length != 0) {
                length = prefixArray[length - 1];
                i--; 
            } 
            else
                prefixArray.push_back(0);
        }
    }   
}

/**
 * @brief Algoritmo KMP para encontrar un patrón en un mensaje, regresando la posición en la que se encuentra
 * 
 * @param message - mensaje en donde se busca el patrón
 * @param pattern - patrón que se busca dentro del mensaje
 */
void KMP(string message, string pattern){

    int N = message.size(), M = pattern.size();
    vector<int> prefArray;
    prefixArray(pattern, M, prefArray);

    int i =0, j=0;

    while(i < N) {
        if (message[i] == pattern[j]) {
            i++;
            j++;
        } else {
            if (j != 0) 
                j = prefArray[j-1];
            else 
                i++;
        }
        if (j == M) { 
            cout << "true, start at position " << i-j << endl;
            j = prefArray[j-1];
        }
    }
}

/**
 * @brief Función para encontrar el palíndromo más largo en un mensaje usando el algoritmo de Manacher
 * 
 * @param message - mensaje en donde se busca el palíndromo
 */
void findPalindrome(string message) {
    int n = message.size();
    vector<char> Q;
    for (int i = 0; i < n; i++) {
        Q.push_back('|');
        Q.push_back(message[i]);
    }
    Q.push_back('|');

    int P[Q.size()] = {0};

    int center = 0, right = 0, iMirror;
    for (int i = 2; i < Q.size(); i++)  
    {
        iMirror = center-(i-center);
        
        if (right > i) {
            P[i] = min(right-i, P[iMirror]);
        }

        while (Q[i+1+P[i]] == Q[i-1-P[i]]) {
            P[i] = P[i]+1;
        }

        if (i+P[i] > right) {
            center = i;
            right = i+P[i];
        }
    }

    // Encontrar el palindromo más grande
    int maxPalindrome = 0, centerIndex = 0;
    for (int i = 2; i < Q.size(); i++) {
        if (maxPalindrome < P[i]){
            maxPalindrome = P[i];
            centerIndex = i;
        }
    }
    int position = (centerIndex-maxPalindrome)/2;
    cout<<"mirrored code found, start at " << position ;
    cout<<", ended at " << position + maxPalindrome << endl;
}

/**
 * @brief Función para encontrar la subcadena más grande en común entre 2 strings
 * 
 * @param A - cadena 1 con la que se comparará
 * @param B - cadena 2 con la que se comparará
 */
void longestCommonSubstring(string A, string B){
    int m = A.size(), n = B.size(); 
    vector<vector<int>> mat;
    vector<int> temp;
    for(int i = 0; i< m+1; i++){
        for(int j = 0; j< n+1; j++){
            temp.push_back(0);
        }
        mat.push_back(temp);
        temp.clear();
    }

    for (int i = 1; i < m+1; i++) {
        for (int j = 1; j < n+1; j++) {
            if (A[i-1] == B[j-1]) {
                mat[i][j] = 1 + mat[i-1][j-1];
            }
            else{
                mat[i][j] = max(mat[i-1][j], mat[i][j-1]);
            }
        }   
    }

    cout << "\nthe longest common substring between transmission1.txt and transmission2.txt is " << mat[m][n]+1 << " characters long" << endl;
}


/**
 * @brief Función principal para las 3 partes
 */
int main() {

    /**
     * Lectura de archivos y se guardan en cadenas
     */
    string strTransmission1, strTransmission2, strMcode1, strMcode2, strMcode3;
    ifstream transmission1("transmission1.txt"), transmission2("transmission2.txt"), mcode1("mcode1.txt"), mcode2("mcode2.txt"), mcode3("mcode3.txt");
    while ( transmission1 ) 
        transmission1 >> strTransmission1;
    
    while ( transmission2 ) 
        transmission2 >> strTransmission2;
    
    while ( mcode1 ) 
        mcode1 >> strMcode1;
    
    while ( mcode2 ) 
        mcode2 >> strMcode2;

    while ( mcode3 ) 
        mcode3 >> strMcode3;
    
    

    /**
     * *********************** PARTE 1 *********************
     * Códigos maliciosos dentro de archivos de transmisión
     * *****************************************************
     */
    cout << "transmission1.txt:" << endl;
    cout << "mcode1.txt - ";
    KMP(strTransmission1, strMcode1);
    cout << "mcode2.txt - ";
    KMP(strTransmission1, strMcode2);
    cout << "mcode3.txt - ";
    KMP(strTransmission1, strMcode3);
    
    cout << "\ntransmission2.txt:" << endl;
    cout << "mcode1.txt - ";
    KMP(strTransmission2, strMcode1);
    cout << "mcode2.txt - ";
    KMP(strTransmission2, strMcode2);
    cout << "mcode3.txt - ";
    KMP(strTransmission2, strMcode3);

    /**
     * ************************ PARTE 2 ************************
     * Encontrar palíndromo más largo en mensajes de transmisión
     * *********************************************************
     */
    cout << "\ntransmission1.txt:" << endl;
    findPalindrome(strTransmission1);
    cout << "\ntransmission2.txt:" << endl;
    findPalindrome(strTransmission2);

    /**
     * ****************************** PARTE 3 **********************************
     * Longitud de la subsecuencia más larga entre ambos mensajes de transmisión
     * *************************************************************************
     */
    longestCommonSubstring(strTransmission1, strTransmission2);                                                        
    
    return 0;
}
