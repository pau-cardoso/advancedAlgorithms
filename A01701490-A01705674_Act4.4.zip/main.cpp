/*
* @author: Paulina Cardoso Fuentes - A01701490
* @author: Paola Adriana Millares Forno - A01705674
* @date: Nov 07 2021
*/

#include <bits/stdc++.h>

using namespace std;

/*
* Coloca el pivote en el lugar que le corresponde. 
* Cuenta cuantos elementos mas grandes y mas pequeños que el pivote existen en el arreglo.
* Envia los elementos más pequeños a la izquierda y los más grandes a la derecha
*/

int partition(int arr[], int low, int high){

	int pivot = arr[low];
	int i = low - 1, j = high + 1;

	while (true){
    
    // Elementos más grandes al pivote
		do {
      i++;
    } while (arr[i] < pivot);

		// Elementos más pequños al pivote
		do {
      j--;
    } while (arr[j] > pivot);
			
		// Si la cantidad de elementos grandes y pequeños es igual
		if (i >= j){
      return j;
    }
			
    // Se intercambia el elemento grande por el pequeño 
		swap(arr[i], arr[j]);
	}
}

/**
* Define el pivote aleatorio con el que se empezara
*/
int randomized(int arr[], int low, int high){

	// Se crea un numero aleatorio entre low y high
  srand(time(NULL));
	int random = low + rand() % (high - low);

	swap(arr[random], arr[low]);

	return partition(arr, low, high);
}


/*
* Funcion recursiva que realiza
* el quicksort para cada particion
* del arreglo
*/
void quickSort(int arr[], int low, int high){

	if (low < high) {
		// Posicion de la particion
		int pi = randomized(arr, low, high);

    // Realiza quicksort para cada lado de la particion
		quickSort(arr, low, pi);
		quickSort(arr, pi + 1, high);
	}
}




/**************
* Codigo main
***************/
int main(){
  string fileName;
  cout << "Ingrese el nombre del archivo de texto que desea ordenar. (example.txt)\n";
  cin >> fileName;

  ifstream file;
    file.open(fileName, ifstream::in);
    int n, test, temp, i;
    file >> test;
    n = test;
    int arr[n];
    i = 0;

    while(test--){
        file >> temp;
        arr[i] = temp;
        i++;
    }

  cout << "clock start" << endl;

  clock_t tStart = clock();
  quickSort(arr, 0, n - 1);
  printf("Tiempo Quick Sort: %.8fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

  for(int i = 0; i < n; i++){
    cout << arr[i] << " ";
  }
  
	return 0;
}